<?php

return [
 'fecshop'  => 'de_DE fecshop',
];
