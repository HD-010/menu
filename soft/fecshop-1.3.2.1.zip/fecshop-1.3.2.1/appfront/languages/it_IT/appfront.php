<?php

return [
 'fecshop'  => 'it_IT fecshop',
];
