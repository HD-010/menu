<?php

return [
 'fecshop'  => 'ru_RU fecshop',
];
