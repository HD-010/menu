<?php

return [
    //'fecshop\app\appfront\helper\test\My' => '@appfront/helper/My.php',
    //"fecshop\models\mongodb\Category"=>"@appadmin/local/local_models/mongodb/Category.php",
];
