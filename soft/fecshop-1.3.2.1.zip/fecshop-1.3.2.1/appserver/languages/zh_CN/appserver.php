<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
return [
    'fecshop'  => 'zh_CN app fecshop',
    'my_color'                  => '我的颜色',
    'my_size'                   => '我的尺码' ,
    'my_size2'                  => '我的尺码2' ,
    'my_size3'                  => '我的尺码3', 
];
