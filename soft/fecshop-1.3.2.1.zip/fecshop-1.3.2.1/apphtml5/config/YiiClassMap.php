<?php

return [
    //'fecshop\app\apphtml5\helper\test\My' => '@apphtml5/helper/My.php',

];
