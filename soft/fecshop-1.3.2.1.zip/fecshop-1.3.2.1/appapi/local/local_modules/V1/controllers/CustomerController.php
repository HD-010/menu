<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */

namespace appapi\local\local_modules\V1\controllers;

use fecshop\app\appfront\modules\AppfrontController;
use Yii;

/**
 * @author Terry Zhao <2358269014@qq.com>
 * @since 1.0
 */
class CustomerController extends  \fecshop\app\appapi\modules\V1\controllers\CustomerController
{
    public function actionIndex(){
        
        echo 1;exit;
    }
    
    
    
}