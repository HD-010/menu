MongoDB Extension for Yii 2
===========================

cet extention vous permet l'integration de [MongoDB](https://www.mongodb.com/) pour Yii2 framework.

Mise en Route
---------------

* [Installation](installation.md)
* [Simple Utilisation](basic-usage.md)
