<?php

return [
    //'fecshop\app\appfront\helper\test\My' => '@appfront/helper/My.php',

];
