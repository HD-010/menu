<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 *
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
return [
    'fecshoplang' => [
        //'class' => 'fecshop\services\FecshopLang',
        /*
        'allLangCode' => [
            'en_US' => 'en',
            'fr_FR' => 'fr',
            'de_DE' => 'de',
            'es_ES' => 'es',
            'ru_RU' => 'ru',
            'pt_PT' => 'pt',
            'zh_CN' => 'zh',
        ],
        'defaultLangCode' => 'en',
        */
    ],
];
