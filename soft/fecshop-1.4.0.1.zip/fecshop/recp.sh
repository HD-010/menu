#!/bin/sh
\cp -rf /www/web/develop/fecshop_app_advanced/*  /www/web/develop/fecshop/