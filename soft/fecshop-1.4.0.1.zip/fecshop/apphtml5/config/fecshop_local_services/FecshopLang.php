<?php
/**
 * FecShop file.
 *
 * @link http://www.fecshop.com/
 *
 * @copyright Copyright (c) 2016 FecShop Software LLC
 * @license http://www.fecshop.com/license/
 */
return [
    // 在@common/config/fecshop_local_services中已经进行了全局配置
    // 当然，您可以将上面里面的配置清空，在每一个app里面单独配置。
    'fecshoplang' => [
        //'defaultLangCode' => 'en',
    ],
];
