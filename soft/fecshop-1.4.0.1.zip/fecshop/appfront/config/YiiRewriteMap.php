<?php

return [
    /**
     * \fecshop\models\mongodb\Category 为原来的类
     * \appfront\local\local_models\mongodb\Category 为重写后的类
     * 重写后的类可以集成原来的类。
     */
    '\fecshop\models\mongodb\Category'  => '\appfront\local\local_models\mongodb\Category',
    //'\fecshop\app\appfront\modules\Cms\block\home\Index'  => '\appfront\local\local_modules\Cms\block\home\Index',
];