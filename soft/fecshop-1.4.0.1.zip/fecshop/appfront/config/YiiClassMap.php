<?php

return [
    //'fecshop\app\appfront\helper\test\My' => '@appfront/helper/My.php',
    //'fecshop\services\Service'  => '@fecshop/enterprise/services/Service.php',
];
