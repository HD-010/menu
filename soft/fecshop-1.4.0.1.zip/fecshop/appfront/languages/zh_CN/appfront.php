<?php

return [
 'Follow Us'                    => '关注我们',
];
